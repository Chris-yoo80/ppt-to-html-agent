---
name: ppt-to-html
license: See LICENSE for internal-use terms and the presentation output exception.
description: Reconstruct PPT or PPTX material as an interactive HTML presentation with staged reveals and optional point-line-plane motion graphics. Use for presentation conversion and iterative editing, rather than pixel-perfect PPT reproduction or unrelated website creation.
---

# PPT to HTML presentation agent

Use the user's source material to build an HTML presentation with deliberate narrative and interaction. Preserve source meaning and distinguish sourced facts from illustrative data.

## Establish the brief

Read [references/intake.md](references/intake.md) before starting a new deck. Ask the required settings together in a short numbered form. Reuse settings already supplied; ask only for missing values. Let the user choose the recommended preset as one answer. Do not start rendering a new deck until these settings are answered or the user explicitly delegates their choice. Continue source inspection while awaiting answers.

Inspect the source with the tools available in the host. Extract text, tables, figures, slide order and relevant notes; use slide rendering when available to inspect spatial relationships. Report unavailable extraction or rendering capabilities. Do not claim extraction succeeded when only part of the source was read. For unreadable sources, identify the specific limitation and request an accessible export.

Ask whether the user has a design reference: website URL, GitHub repository, local HTML, screenshot/image, named style, or a bundled preset. When supplied, read [references/design-references.md](references/design-references.md). Record what was actually inspected, the elements to apply, similarity level and permission/license status. Default to visual inspiration and newly authored implementation. Do not copy branding, text, icons, images, demo data, DOM or CSS merely because it is publicly viewable. Code or asset reuse requires a verified license source and retained notices.

For accessible PPTX inputs and the bundled HTML starter, read [references/authoring.md](references/authoring.md). It documents the extraction and build commands, supported scene format, chart scenes (bar, line, funnel, donut) and actual tool limitations. Give every numeric comparison, trend, funnel or share its own chart; do not reduce numeric slides to text cards. For business reports, reviews and proposals, write composed scenes (agent-authored HTML/SVG with spotlight steps, chapter tabs and backup scenes) rather than card scenes. The host AI performs interpretation and planning; the builder renders an authored outline.

## Design each deck for its content

The bundled charts, component kit and `consulting`/`executive` presets are a starting vocabulary, not a template. Decide the visual direction from the content, audience and brand first, then pick or invent the components that express it.

- If the host offers design skills (for example a frontend-design, UI/UX or data-visualization skill), load them before the representative scene and apply their guidance on typography, color, layout rhythm and chart choice. Name the skills used in the final report. The deck must still build without them.
- For more references, read [references/design-sources.md](references/design-sources.md). It separates look-only galleries from sources whose icons, chart patterns, palettes or code may be reused under license.
- Let each scene's job choose its composition, and vary it across the deck:

  | What the scene must show | Composition to consider |
  |---|---|
  | One headline number | full-width hero number with a single supporting chart |
  | Comparison | side-by-side panels, bar chart, table with a highlighted row |
  | Trend | wide line chart with annotated turning points |
  | Process or flow | diagram-led scene: chevrons, swimlanes, custom SVG flow |
  | Space or structure | custom SVG illustration (layout, isometric building, map) with callouts |
  | Plan or schedule | Gantt or milestone timeline |
  | Decision or ask | one bold statement, minimal supporting evidence |
  | Voices or qualitative findings | quote cards, icon grid |

- Do not repeat the same grid on consecutive scenes unless the content repeats. Alternate dense evidence scenes with sparse statement scenes.
- Style the deck through its `css` field: own classes, color variables, gradients, finite `@keyframes` with a reduced-motion fallback, per-scene rules via `[data-scene="scene-id"]`. Draw illustrations in inline SVG. Override or replace the presets freely.
- What stays fixed: one offline file, no scripts, no remote URLs, numbers traceable to the source, and the shared navigation, steps, print and bookmark behavior.

## Plan and create

Map source slides to proposed HTML scenes. Identify the key message, evidence, reveal steps and suitable motion for each scene. Keep figures, units and assumptions traceable to the source. Mark sample data explicitly; do not invent results or introduce business assertions as facts.

For a new visual direction, present the scene outline and one representative scene before extending it to the whole deck. Reuse prior approval during later edits. Ask about material changes to scope, claims or narrative; decide routine implementation details independently.

In Reference Design Mode, create a `design-reference.json` manifest before the representative scene. Apply abstract design tokens and interaction patterns with project-owned HTML/CSS/SVG, preserve the offline single-file requirement, and keep all existing navigation, reduced-motion, print and question-bookmark behavior. The final report must state Reference / Inspected / Applied / Excluded / License or permission / Runtime dependency / Needs review.

Use HTML/CSS/SVG and local resources where they meet the brief. Preserve aspect ratio, make Korean wrapping readable, and make scene and substep navigation predictable. Separate editable content from playback logic where practical. Provide visible previous/next controls and usage instructions. Use an explicitly chosen end behavior rather than assuming the deck should loop.

When motion is requested, read [references/motion.md](references/motion.md). Treat motion amount and playback mode as separate settings. A single-file offline requirement includes fonts, images and other dependencies; avoid external runtime dependencies under that requirement.

For video-like delivery, marketing or warehouse process scenes, read [references/motion-stories.md](references/motion-stories.md). The bundled presets provide continuous playback and phase control with editable fictional data; they are not optimization solvers or simulations of a real operation.

For Excel-based charts, interactive slicers or supporting/backup analysis, read [references/supplemental-analysis.md](references/supplemental-analysis.md). Ask for the workbook location, sheets/ranges, and where the resulting analysis should appear (Additional resources, standalone HTML, or both), including its related scene and tab label. Reuse answers already given. Establish the analysis brief before building, start with left-side controls and right-side visual results when requested, and add advanced features after the base is agreed. Deliver the analysis as additional HTML accessible from the presentation; do not silently replace the presentation or attach the raw workbook.

## Verify and deliver

Unit review covers length, area, volume, mass, time, speed, energy/power, compound and business units as well as money/counts/ratios. For supported declared conversions use `scripts/unit_audit.py`; record source/display units, dimensions, factor and definition source. Unsupported units or missing business definitions are Needs review. This tool checks declared arithmetic, not automatic extraction or agreement with arbitrary workbooks.

For numeric content, read [references/numeric-verification.md](references/numeric-verification.md). Check source units/display conversions, denominator definitions, filters/aggregation ranges, rounding, motion-off/print retention of essential numbers and explanations, and sheet/range provenance. Final reports must include one row per item: **Item / Passed or Needs review / Evidence or unresolved issue** (Korean: **항목 / 통과 또는 확인 필요 / 근거·남은 확인**). Unavailable source or unperformed checks are Needs review, never an inferred pass from successful generation.

Ask about PDF output and backup resource files, placement and tab labels in the initial brief. The bundled Print / PDF button prints all scenes with every reveal visible, one scene per A4 landscape page. Supporting analysis prints its current filters and optional sections separately; resources are not automatically merged into the deck PDF. Preserve the presentation step and pause autoplay after printing. Verify print layout and page count separately from interactive playback.

Check source fidelity, every scene/substep, forward/backward transitions, the contents panel, exact scene/step jumps, question bookmarks and return, timers on scene changes, replay and end behavior. The bundled player uses G for contents, B to mark the current question position, Shift+B for the bookmark list and R to return to the latest mark. Verify that opening and closing supporting resources preserves both the presentation step and bookmark list. Check text clipping, overflow, keyboard access and reduced-motion behavior at the agreed output size. For a requested print/PDF mode, inspect the rendered output separately from presentation screenshots.

Distinguish static checks from browser checks. If the host cannot render or operate the output, name the limitation and list the unverified behaviors; do not describe the presentation as visually verified. Do not bypass tool security restrictions to obtain rendering access.

Deliver the HTML, editable sources and brief operation notes supported by the actual implementation. Report what was tested and what remains unverified. Do not claim MP4 export, installed dependencies, offline support or host compatibility without checking them.

Keep the Package's LICENSE with copies of the skill and retain the builder's embedded legal notice and license text in presentation outputs. Personal, noncommercial and internal organizational use is permitted without a fee; external generation businesses and paid redistribution of the tool require separate permission. Completed presentations can be shared for the communication purposes in the output exception. A visible author watermark is a separate design choice, not a requirement of this license.

## Publishing examples

User-provided decks are working inputs, not automatically public examples. When preparing this project's public repository, exclude company documents, embedded images/videos, notes, hidden data, internal paths and derived business content. Use independently authored fictional examples. Do not publish or push as part of an ordinary conversion request.
